function execute(url) {
    var browser = Engine.newBrowser();
    browser.setUserAgent(UserAgent.chrome());
    browser.launchAsync(url);
    sleep(5000);
    doc = browser.html();
    browser.close();
    var content = doc.select(".read-content").html();
    return Response.success(content);
}
