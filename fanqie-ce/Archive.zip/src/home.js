function execute() {
    return Response.success(
[

{title: "都市",input: "https://novel.snssdk.com/api/novel/channel/homepage/new_category/book_list/v1/?parent_enterfrom=novel_channel_category.tab.&aid=1967&offset={{page}}&limit=100&category_id=1&gender=1", script: "gen2.js"},


]
    
    );
}