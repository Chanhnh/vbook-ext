load('config.js');

function execute(url) {
    const regex = /(?:item_id=|\/)(\d+)$/;
    let chapid = url.match(regex)[1];
    let chapterUrl = "https://api.cenguigui.cn/api/tomato/content.php?item_id=" + chapid;
    let response = fetch(chapterUrl)
    if (response.ok) {
        let json = response.json();
        let content = json.data.content.replace(/<br\s*\/?>|\n/g, "<br><br>");
        return Response.success(content);
    }

    return Response.error("Ăn loz rồi!!!\n\Đã bảo không tải rồi mà :(((.\n\Chi tiết tại: bit.ly/fq-ce");
}
