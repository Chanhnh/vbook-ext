function execute() {
    return Response.success([
        { title: "Đề xuất", input: "recommend", script: "search.js" }
    ]);
}
