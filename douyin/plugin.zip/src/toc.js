load('config.js');

function execute(url) {
    if (!url) return Response.error("URL video không hợp lệ");
    return Response.success([
        { name: "Xem video", url: url, lock: false, pay: false }
    ]);
}
