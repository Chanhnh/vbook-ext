load('config.js');

function execute(query, page) {
    var keyword = String(query || "").trim();
    var pageNum = parseInt(page, 10);
    if (isNaN(pageNum) || pageNum < 1) pageNum = 1;

    // 1. Phân nhánh duyệt Đề xuất (Home feed)
    if (!keyword || keyword === "recommend") {
        var feedList = fetchFeedBatch(pageNum);
        var items = [];
        for (var i = 0; i < feedList.length; i++) {
            var item = feedList[i];
            if (!item || !item.aweme_id) continue;

            var id = String(item.aweme_id);
            var title = item.desc ? String(item.desc).trim() : "Douyin Video " + id;
            var author = item.author && item.author.nickname ? item.author.nickname : "";
            var video = item.video || {};
            var cover = "";
            if (video.cover && video.cover.url_list && video.cover.url_list.length > 0) {
                cover = video.cover.url_list[0];
            } else if (video.origin_cover && video.origin_cover.url_list && video.origin_cover.url_list.length > 0) {
                cover = video.origin_cover.url_list[0];
            }

            var uri = video.play_addr && video.play_addr.uri ? video.play_addr.uri : "";
            var link = BASE_URL + "/video/" + id;
            if (uri) link += "?uri=" + encodeURIComponent(uri);

            var statistics = item.statistics || {};
            var duration = video.duration || item.duration || 0;
            var tags = [];
            if (duration) tags.push(formatDuration(duration));
            if (statistics.digg_count) tags.push(formatCount(statistics.digg_count) + " ❤️");
            if (statistics.comment_count) tags.push(formatCount(statistics.comment_count) + " 💬");
            if (item.create_time) tags.push(formatTime(item.create_time));

            var result = {
                name: author,
                link: link,
                description: title,
                type: "short"
            };
            if (cover) result.cover = cover;
            if (tags.length > 0) result.tag = tags.join(" · ");
            items.push(result);
        }

        var nextPage = items.length > 0 ? String(pageNum + 1) : "";
        return Response.success(items, nextPage);
    }

    // 2. Phân nhánh tìm kiếm trực tiếp bằng ID video hoặc link chứa ID
    var idMatch = keyword.match(/(\d{15,22})/);
    var videoId = idMatch ? idMatch[1] : "";
    if (videoId) {
        var videoItem = fetchVideoInfo(videoId);
        if (!videoItem) {
            return Response.error("Không tìm thấy video Douyin với ID: " + videoId);
        }

        var v = videoItem.video || {};
        var vTitle = videoItem.desc ? String(videoItem.desc).trim() : ("Douyin Video " + videoId);
        var vAuthor = videoItem.author && videoItem.author.nickname ? videoItem.author.nickname : "";
        var vCover = "";
        if (v.cover && v.cover.url_list && v.cover.url_list.length > 0) {
            vCover = v.cover.url_list[0];
        } else if (v.origin_cover && v.origin_cover.url_list && v.origin_cover.url_list.length > 0) {
            vCover = v.origin_cover.url_list[0];
        }

        var vUri = v.play_addr && v.play_addr.uri ? v.play_addr.uri : "";
        var vLink = BASE_URL + "/video/" + videoId;
        if (vUri) vLink += "?uri=" + encodeURIComponent(vUri);

        var vStats = videoItem.statistics || {};
        var vDuration = v.duration || videoItem.duration || 0;
        var vTags = [];
        if (vDuration) vTags.push(formatDuration(vDuration));
        if (vStats.digg_count) vTags.push(formatCount(vStats.digg_count) + " ❤️");
        if (vStats.comment_count) vTags.push(formatCount(vStats.comment_count) + " 💬");
        if (videoItem.create_time) vTags.push(formatTime(videoItem.create_time));

        var singleResult = {
            name: vAuthor,
            link: vLink,
            description: vTitle,
            type: "short"
        };
        if (vCover) singleResult.cover = vCover;
        if (vTags.length > 0) singleResult.tag = vTags.join(" · ");

        return Response.success([singleResult], "");
    }

    return Response.error("Nguồn này chỉ hỗ trợ duyệt Đề xuất hoặc dán ID/link video Douyin.");
}
