load('config.js');

function execute(url) {
    var match = String(url || "").match(/(\d{15,22})/);
    var videoId = match ? match[1] : "";
    if (!videoId) return Response.error("Không tìm thấy ID video Douyin");

    var uriMatch = String(url || "").match(/[?&]uri=([^&#]*)/);
    var videoUri = uriMatch ? decodeURIComponent(uriMatch[1]) : "";
    if (!videoUri) {
        var item = fetchVideoInfo(videoId);
        if (item && item.video && item.video.play_addr) {
            videoUri = item.video.play_addr.uri || "";
        }
    }
    if (!videoUri) return Response.error("Douyin không cung cấp nguồn MP4 cho video này");

    var playUrl = BASE_URL + "/aweme/v1/play/?video_id=" + encodeURIComponent(videoUri) + "&item_id=" + videoId;
    return Response.success([
        { title: "Douyin MP4", data: playUrl }
    ]);
}
