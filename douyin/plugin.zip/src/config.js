var BASE_URL = "https://www.douyin.com";
try {
    if (DOMAIN) {
        BASE_URL = String(DOMAIN).replace(/\/+$/, "");
    }
} catch (e) {
}
var MOBILE_UA = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36";
try {
    if (typeof UserAgent !== "undefined" && UserAgent.android) {
        MOBILE_UA = UserAgent.android() || MOBILE_UA;
    }
} catch (e) {
}

var FEED_PARAMS = "device_platform=android&aid=1128&channel=bytedance";
try {
    if (ORIENTATION === "Ngang") {
        FEED_PARAMS = "device_platform=webapp&aid=6383&channel=channel_pc_web";
    }
} catch (e) {
}

function fetchVideoInfo(videoId) {
    if (!videoId) return null;

    var shareUrl = "https://www.iesdouyin.com/share/video/" + videoId + "/";
    try {
        var res = fetch(shareUrl, {
            headers: {
                "User-Agent": MOBILE_UA,
                "Cookie": getCookie()
            },
            timeout: 30000
        });
        if (!res.ok) return null;

        var html = res.text();
        var match = html.match(/window\._ROUTER_DATA\s*=\s*(.*?);?\s*<\/script>/);
        if (!match) return null;

        var json = JSON.parse(match[1]);
        var loader = json.loaderData || {};
        for (var key in loader) {
            var page = loader[key];
            if (!page || !page.videoInfoRes) continue;
            var items = page.videoInfoRes.item_list || [];
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (item && String(item.aweme_id || "") === String(videoId)) return item;
            }
            if (items.length > 0 && items[0]) return items[0];
        }
    } catch (e) {
    }
    return null;
}

function formatCount(num) {
    if (!num || isNaN(num) || Number(num) <= 0) return "";
    var value = Number(num);
    if (value >= 10000) {
        return (value / 10000).toFixed(1).replace(/\.0$/, "") + " vạn";
    }
    return value.toString();
}

function formatDuration(value) {
    if (!value || isNaN(value) || Number(value) <= 0) return "";
    var duration = Number(value);
    var totalSeconds = Math.round(duration >= 1000 ? duration / 1000 : duration);
    var hours = Math.floor(totalSeconds / 3600);
    var minutes = Math.floor((totalSeconds % 3600) / 60);
    var seconds = totalSeconds % 60;
    var secondText = (seconds < 10 ? "0" : "") + seconds;
    var minuteText = (minutes < 10 ? "0" : "") + minutes;
    if (hours > 0) return hours + ":" + minuteText + ":" + secondText;
    return minuteText + ":" + secondText;
}

function formatTime(timestamp) {
    if (!timestamp || isNaN(timestamp) || Number(timestamp) <= 0) return "";
    var now = Math.floor(Date.now() / 1000);
    var diff = now - Number(timestamp);
    if (diff > 0 && diff < 60) return "Vừa xong";
    if (diff >= 60 && diff < 3600) return Math.floor(diff / 60) + " phút trước";
    if (diff >= 3600 && diff < 86400) return Math.floor(diff / 3600) + " giờ trước";
    if (diff >= 86400 && diff < 2592000) return Math.floor(diff / 86400) + " ngày trước";

    var date = new Date(Number(timestamp) * 1000);
    if (isNaN(date.getTime())) return "";
    var year = date.getFullYear();
    var month = date.getMonth() + 1;
    var day = date.getDate();
    return (day < 10 ? "0" : "") + day + "-" + (month < 10 ? "0" : "") + month + "-" + year;
}

function getTtwid() {
    try {
        var res = fetch("https://ttwid.bytedance.com/ttwid/union/register/", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "User-Agent": MOBILE_UA
            },
            body: JSON.stringify({
                region: "cn",
                aid: 1768,
                needFid: "0",
                service: "www.ixigua.com",
                migrate_info: { ticket: "", source: "node" },
                cbUrlProtocol: "https",
                union: true
            }),
            timeout: 15000
        });
        if (!res.ok) return "";
        var setCookie = res.header("set-cookie") || "";
        var match = setCookie.match(/ttwid=([^;]+)/i);
        return match ? match[1] : "";
    } catch (e) {
        return "";
    }
}

function getCookie() {
    var cookie = "";
    try {
        if (typeof localCookie !== "undefined") {
            cookie = String(localCookie.getCookie() || "").trim();
        }
    } catch (e) {
        cookie = "";
    }

    if (!/(^|;\s*)ttwid=/i.test(cookie)) {
        var ttwid = getTtwid();
        if (ttwid) cookie = (cookie ? cookie + "; " : "") + "ttwid=" + ttwid;
    }
    return cookie;
}

function fetchFeedBatch(refreshIndex) {
    var index = parseInt(refreshIndex, 10);
    if (isNaN(index) || index < 1) index = 1;
    var url = BASE_URL + "/aweme/v1/web/tab/feed/?" + FEED_PARAMS + "&count=10&refresh_index=" + index;
    try {
        var res = fetch(url, {
            headers: {
                "User-Agent": MOBILE_UA,
                "Referer": BASE_URL + "/",
                "Cookie": getCookie()
            },
            timeout: 30000
        });
        if (!res.ok) return [];
        var json = res.json();
        return json.aweme_list || [];
    } catch (e) {
        return [];
    }
}
