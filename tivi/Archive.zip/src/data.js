var DATA = {
    "categories": {
        "THỂ THAO QUỐC TẾ": [
            {
                "name": "Sky Sport F1",
                "logo": "https://r2.thesportsdb.com/images/media/channel/logo/p5csyn1620551587.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1149423&extension=ts&play_token=1jkVQWGCqc"
            },
            {
                "name": "Sky Sport Tennis",
                "logo": "https://e0.365dm.com/24/01/2048x1152/skysports-sky-sports-tennis_6437040.jpg",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1149433&extension=ts&play_token=Y1kv3yxPS8"
            },
            {
                "name": "Canal+ Sport",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/1/1a/Canal%2B_Sport_2015.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=958758&extension=ts&play_token=MskDtCSrpn"
            },
            {
                "name": "TNT Sports 1 4Mbps for 4G",
                "logo": "https://media.info/l/o/1/1539.1690027797.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=894977&extension=ts&play_token=W2HvDO5iES"
            },
            {
                "name": "TNT Sports 2 4Mbps for 4G",
                "logo": "https://media.info/l/o/1/1540.1690027877.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1091517&extension=ts&play_token=zKzxFKTNmb"
            },
            {
                "name": "TNT Sports 3 4Mbps for 4G",
                "logo": "https://media.info/l/o/5/5712.1690027954.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=894979&extension=ts&play_token=RLLwKaJKqY"
            },
            {
                "name": "TNT Sports 4 4Mbps for 4G",
                "logo": "https://media.info/l/o/1/1491.1690027975.png",
                "group": "THỂ THAO QUỐC TẾ",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=894980&extension=ts&play_token=4ofwEIdTU4"
            }
        ],
        "⚽| Thể thao quốc tế": [
            {
                "name": "Canal+ Foot",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/e/eb/Canal%2BFoot.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941405&extension=ts&play_token=ODWyLygMWo"
            },
            {
                "name": "CANAL+ LIVE 1",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941442&extension=ts&play_token=6sw55uPREH"
            },
            {
                "name": "CANAL+ LIVE 2",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941443&extension=ts&play_token=BO2CiGVxUy"
            },
            {
                "name": "CANAL+ LIVE 3",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941444&extension=ts&play_token=lWRMv4h4G6"
            },
            {
                "name": "CANAL+ LIVE 4",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941444&extension=ts&play_token=T8Adfmt7Vu"
            },
            {
                "name": "CANAL+ LIVE 5",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941446&extension=ts&play_token=onKUvLJ1FX"
            },
            {
                "name": "CANAL+ LIVE 6",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941447&extension=ts&play_token=VmOfMyrDfy"
            },
            {
                "name": "CANAL+ LIVE 7",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941449&extension=ts&play_token=uUpqkgtfue"
            },
            {
                "name": "CANAL+ LIVE 8",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941468&extension=ts&play_token=oLegwjYDD5"
            },
            {
                "name": "CANAL+ LIVE 9",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.ciao-ott.net:80/play/live.php?mac=00:1A:79:C8:7B:30&stream=941470&extension=ts&play_token=10cpSzSEsB"
            },
            {
                "name": "CANAL+ LIVE 10",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941470&extension=ts&play_token=2SQs9dSZmM"
            },
            {
                "name": "CANAL+ LIVE 11",
                "logo": "https://s1.dmcdn.net/v/JjNMw1Z-Js5kwK7KN/x720",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941471&extension=ts&play_token=ReuCTADsrG"
            },
            {
                "name": "CANAL+ LIVE 12",
                "logo": "https://cdn.livesoccertv.com/images/channels/thumbnails/canalplus-live-12.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=941472&extension=ts&play_token=3EM8alU2An"
            },
            {
                "name": "MUTV",
                "logo": "https://m.media-amazon.com/images/I/611NwkDJjOL.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.ciao-ott.net:80/play/live.php?mac=00:1A:79:C8:7B:30&stream=1312824&extension=ts&play_token=3ouilCRXf9"
            },
            {
                "name": "Polsat Sport 1",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/e/e3/Polsat_Sport_1_2024.svg/250px-Polsat_Sport_1_2024.svg.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1729162&extension=ts&play_token=9JXfYd9pyq"
            },
            {
                "name": "Polsat Sport 2",
                "logo": "https://ipla-e2-42.pluscdn.pl/p/cms_thumbnails/qx/qxn4b9d2175hjjvvy4ehpa92nztaynba.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1729164&extension=ts&play_token=vFbihF9Rmr"
            },
            {
                "name": "Polsat Sport 3",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/d2/Polsat_Sport_3_2024.svg/250px-Polsat_Sport_3_2024.svg.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1729168&extension=ts&play_token=ThvjYQPppG"
            },
            {
                "name": "Max Sport 1 HD",
                "logo": "https://r2.thesportsdb.com/images/media/channel/logo/er6tz11641505761.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=228727&extension=ts&play_token=mwh0b4DmEo"
            },
            {
                "name": "Max Sport 2 HD",
                "logo": "https://r2.thesportsdb.com/images/media/channel/logo/8qhlj81641505795.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=228726&extension=ts&play_token=1WFblY6SIm"
            },
            {
                "name": "Max Sport 4 HD",
                "logo": "https://msatcable.com/wp-content/uploads/2023/05/xoceudhlccd61ha1z10u8orii5.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=228724&extension=ts&play_token=TJrfSv76Xi"
            },
            {
                "name": "Eurosport 1",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/3/37/Eurosport1hd.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=933004&extension=ts&play_token=jtuDUMdLno"
            },
            {
                "name": "Eurosport 2",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/d/d5/Eurosport2hd.png",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=933003&extension=ts&play_token=OIqiUqIbWW"
            },
            {
                "name": "Tyc Sport Argentina",
                "logo": "https://television.com.ar/wp-content/uploads/2024/01/276279.jpg",
                "group": "⚽| Thể thao quốc tế",
                "url": "http://line.ciao-ott.net:80/play/live.php?mac=00:1A:79:C8:7B:30&stream=1090606&extension=ts&play_token=UU20nTSWow"
            }
        ],
        "TVB": [
            {
                "name": "TVB VIỆT NAM",
                "logo": "https://tvbaw-na.s3.us-west-1.amazonaws.com/hb/TVB%20Vietnam%20Banner_Side.jpg",
                "group": "TVB",
                "url": "https://amg01868-amg01868c3-tvbanywhere-us-4491.playouts.now.amagi.tv/playlist1080p.m3u8"
            }
        ],
        "Giải Trí": [
            {
                "name": "360 Phim Việt",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/07/15/1775549899305/f54a93a767c5_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=phim-viet",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim Âu Mỹ",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/09/08/1775697767861/9a6dc88794cf_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=phim-au-my",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Hoạt hình",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/07/15/1775549978212/fcfc9c6d7919_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=hoat-hinh",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim Hoa Ngữ",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/09/08/1775697736867/3854900b7263_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-hoa-ngu",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Hành Động Châu Á",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/08/10/1775617851169/1f38a5af77c1_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-hanh-dong-chau-a",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 K-Drama",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/09/21/1775744591740/79928f9b003f_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-k-drama",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Hài - Tình Cảm",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/13/13/1776063183880/03439dc9da19_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-hai-tinh-cam",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim Kinh Điển",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/13/13/1776063200976/6ced2ef539a4_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-phim-kinh-dien",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Anime",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/13/13/1776063223569/462daff06d9d_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-anime",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Thiếu Nhi",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/06/18/13/1781765362332/737c1501b0c5_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-thieu-nhi",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 Phim 4K",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/07/30/10/1785382803894/362700e9107b_640_360.png",
                "group": "Giải Trí",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-phim-4k"
            }
        ],
        "Thể Thao": [
            {
                "name": "360 C1 Châu Âu",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/15/22/177626841934/e289a43bd190_640_360.png",
                "group": "Thể Thao",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-c1-chau-au",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 C2 Châu Âu",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/15/23/1776269925378/3875f76de1cd_640_360.png",
                "group": "Thể Thao",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-c2-chau-au",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "360 C3 Châu Âu",
                "logo": "https://img-zlr1.tv360.vn/image1/2026/04/15/23/1776269965595/9f150757c9e3_640_360.png",
                "group": "Thể Thao",
                "url": "https://vmttv.dpdns.org/tv360/?id=360-c3-chau-au",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "Unknown": [
            {
                "name": "",
                "logo": "",
                "group": "Unknown",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv1/live247-hls-avc/vtv1-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            }
        ],
        "VTV": [
            {
                "name": "VTV2",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV2_ident2026.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv2/live247-hls-avc/vtv2-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV3",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV3.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv3/live247-hls-avc/vtv3-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV4",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV4_ident2026.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv4/live247-hls-avc/vtv4-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "Vietnam Today",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/VietnamToday.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vietnamtoday/live-hls-avc/vietnamtoday-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV5",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV5.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv5/live247-hls-avc/vtv5-avc1_5600000=10000-mp4a_131600=20000.m3u8",
                "headers": {
                    "User-Agent": "cvmedia/1.1.0"
                }
            },
            {
                "name": "VTV5 Tây Nam Bộ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV5TNB.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv5tnb/live-hls-avc/vtv5tnb-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV5 Tây Nguyên",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV5TN.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv5tn/live-hls-avc/vtv5tn-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV6",
                "logo": "1",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv6/live247-hls-avc/vtv6-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV7",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV7.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv7/live247-hls-avc/vtv7-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV8",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/vtv8.jpg",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv8/live-hls-avc/vtv8-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV9",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/VTV9.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv9/live247-hls-avc/vtv9-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "VTV10",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/VTV10.png",
                "group": "VTV",
                "url": "https://vips-livecdn.fptplay.net/live/media/vtv10/live247-hls-avc/vtv10-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            }
        ],
        "VTVcab": [
            {
                "name": "ON Vie Giải Trí",
                "logo": "https://i.ytimg.com/vi/fyT_xa-g-Pk/hq720.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=180",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Phim Việt",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/ONPHIMVIET.png",
                "group": "VTVcab",
                "url": "https://vmttv.dpdns.org/tv360/?id=vtvcab-2-phim-viet-hd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On Movies - You TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onmovies.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=181",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON E- Channel",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onechannel.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=182",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On O2TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/ono2tv.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=136",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On BiBi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onbibi.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=178",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Info TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/oninfotv.png",
                "group": "VTVcab",
                "url": "https://tpninosaga.duckdns.org/source/tv360.m3u8?id=189&token=NinoEra36",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Cine",
                "logo": "https://i.ytimg.com/vi/rwhsuTvSXxo/maxresdefault.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=176",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Style TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/onstyle.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=184",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "On Music",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/07/20/10/1689822524259/0f3a4d1ebfaf_640_360.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=185",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON TRENDING TV",
                "logo": "https://i.ibb.co/k1ccQNr/vcab17.webp",
                "group": "VTVcab",
                "url": "https://tpninosaga.duckdns.org/source/tv360.m3u8?id=186&token=NinoEra36",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON Vie Dramas",
                "logo": "https://i.ytimg.com/vi/4SqDlPT8oEI/maxresdefault.jpg",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=177",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ON V Family",
                "logo": "https://i.ibb.co/HHfL7Dq/cocab20.webp",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=187",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "On Kids",
                "logo": "https://assets-vtvcab.gviet.vn/images/v2/channel/20220613/2022061306/onkids5_1675158859.webp",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=179",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "On Life",
                "logo": "https://img-ali1.tv360.vn/image1/2023/07/19/09/1689732652862/f124f55c3587_640_360.png",
                "group": "VTVcab",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=188",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "On Golf",
                "logo": "https://img.lichphatsong.site/logo/on-golf.jpg",
                "group": "VTVcab",
                "url": "https://vmttv.dpdns.org/tv360/?id=vtvcab-23-golf-channel",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "SCTV": [
            {
                "name": "SCTV1",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv1.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv1"
            },
            {
                "name": "SCTV2 - TODAY TV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV2TODAYTV.jpg",
                "group": "SCTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=201",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV3",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv3.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv3"
            },
            {
                "name": "SCTV4",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv4.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv4"
            },
            {
                "name": "SCTV5",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV5.jpg",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv5"
            },
            {
                "name": "SCTV6",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv6.png",
                "group": "SCTV",
                "url": "https://live.fptplay53.net/epzhd2/film360_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "SCTV7",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv7.webp",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv7"
            },
            {
                "name": "SCTV8",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv8.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv8"
            },
            {
                "name": "SCTV9",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV9.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv9"
            },
            {
                "name": "SCTV10",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV10.jpg",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv10"
            },
            {
                "name": "SCTV11",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv11.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv11"
            },
            {
                "name": "SCTV12",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv12.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv12"
            },
            {
                "name": "SCTV13",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv13.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv13"
            },
            {
                "name": "SCTV14",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv14.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv14"
            },
            {
                "name": "SCTV15",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV15.png",
                "group": "SCTV",
                "url": "https://liveatmvng.vtvprime.vn/live/data8/SCTV15HD/Live_DASHDRM/SCTV15HD.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV16",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv16.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv16"
            },
            {
                "name": "SCTV17",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV17.png",
                "group": "SCTV",
                "url": "https://liveatmvng.vtvprime.vn/live/data8/SCTV17/Live_DASHDRM/SCTV17.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV18",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv18.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv18"
            },
            {
                "name": "SCTV19",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctv19.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv19"
            },
            {
                "name": "SCTV20",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV20.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv20"
            },
            {
                "name": "SCTV21 - Việt Nam Ký Ức",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV21.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctv21"
            },
            {
                "name": "SCTV22",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/SCTV22.png",
                "group": "SCTV",
                "url": "https://liveatmvng.vtvprime.vn/live/data8/SCTV22/Live_DASHDRM/SCTV22.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "SCTV Phim Tổng Hợp",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/sctvpth.png",
                "group": "SCTV",
                "url": "https://vmttv.dpdns.org/VTVGo/?sctvphim"
            },
            {
                "name": "SCTV4K",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/SCTV4K.png",
                "group": "SCTV",
                "url": "https://vietanhtv.id.vn/sctv/sctv-4k/index.m3u8"
            }
        ],
        "📦| In The Box": [
            {
                "name": "Box Movie 1",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/boxmovie1.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/Live_DASHDRM1/BM1/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Hollywood Classics",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/hollywoodclassic.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/Live_DASHDRM1/HC/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Box Hits",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/boxhits.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/mean/BOXHIT/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Music Box",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/07/20/10/1689822939536/68d521f6938e_640_360.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/livesnv2/MUSICBOX/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Woman",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822442611/f6b738c3d05a_640_360.png",
                "group": "📦| In The Box",
                "url": "https://livevlisctcdnw.seenow.vn/Live_DASHDRM1/WO/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "HTV": [
            {
                "name": "HTV1 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://s7771.cdn.mytvnet.vn/vimages/8c/ce/ee/e7/79/98/8cee7-phtv1hd-channel-unkn.png",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=190",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV2 - Vie Channel",
                "logo": "https://s7768.cdn.mytvnet.vn/vimages/a0/07/73/39/9e/e6/a0739-phtv2hd-channel-unkn.png",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=191",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV3 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/HTV3.jpg",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=192",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV4 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/HTV4.jpg",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV5 - B Channel",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/HTV5.jpg",
                "group": "HTV",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=151",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HTV7 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822381421/47d2615f6141_640_360.png",
                "group": "HTV",
                "url": "https://live.fptplay53.net/live/media/htv7/live247-hls-avc/htv7-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "HTV9 - Đài PTTH Thành Phố Hồ Chí Minh",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822390705/a9fc59138d3b_640_360.png",
                "group": "HTV",
                "url": "https://live-a.fptplay53.net/live/media/htv9/live247-hls-avc/htv9-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "HTV Thể Thao",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/04/03/16/1680514594557/ab2557f0b015_640_360.png",
                "group": "HTV",
                "url": "https://live.fptplay53.net/live/media/htvthethao/live247-hls-avc/htvthethao-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "HTVC Plus HD",
                "logo": "https://vietanhtv.id.vn/logo/htvcplus.png",
                "group": "HTV",
                "url": "https://live.fptplay53.net/epzhd1/htvcplus_vhls.smil/chunklist_b5000000.m3u8"
            }
        ],
        "HTVC": [
            {
                "name": "HTVC Thuần Việt",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/htvcthuanviet.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcthuanviethd_vhls.smil/chunklist.m3u8"
            },
            {
                "name": "HTVC Gia đình HD",
                "logo": "",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcgiadinh_vhls.smil/chunklist.m3u8"
            },
            {
                "name": "HTVC Phụ nữ HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823432136/86f5cc6afcf6_640_360.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcphunu_vhls.smil/chunklist.m3u8"
            },
            {
                "name": "HTVC Du lịch Cuộc sống HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020/12/25/08/1608860643587/bb01290ccde1_640_360.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcdulich_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "HTVC Ca nhạc HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823449894/0834e6a36f71_640_360.png",
                "group": "HTVC",
                "url": "https://live.fptplay53.net/epzhd1/htvcmusic_vhls.smil/chunklist.m3u8"
            }
        ],
        "🌐| Thiết yếu": [
            {
                "name": "ANTV HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600822516608/b33963dc0df8_640_360.png",
                "group": "🌐| Thiết yếu",
                "url": "https://live.fptplay53.net/fnxhd2/anninhtv_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "QPVN HD",
                "logo": "https://i.ytimg.com/vi/sFLUmdwp0Z8/maxresdefault.jpg",
                "group": "🌐| Thiết yếu",
                "url": "https://live.fptplay53.net/fnxhd2/quocphongvnhd_vhls.smil/chunklist_b5000000.m3u8"
            }
        ],
        "Địa phương": [
            {
                "name": "DRT HD - Báo và PTTH Đắk Lắk",
                "logo": "https://img-zlr1.tv360.vn/image1/2025/06/30/11/1751256466336/bda77a407209_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=51",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "THP HD - Báo và PTTH Hải Phòng",
                "logo": "https://upload.wikimedia.org/wikipedia/vi/9/90/THP-Logo.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/live/media/haiphong/live-hls-avc/haiphong-avc1_4000000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THP3 - Báo và PTTH Hải Phòng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/THP3.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=59",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cần Thơ 1 HD - Báo và PTTH Thành Phố Cần Thơ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/CanTho1.png",
                "group": "Địa phương",
                "url": "https://live.canthotv.vn/live/tv/chunklist_w693005420.m3u8"
            },
            {
                "name": "Cần Thơ 2 HD - Báo và PTTH Thành Phố Cần Thơ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/CanTho2.png",
                "group": "Địa phương",
                "url": "https://live.canthotv.vn/cs2/live.stream/chunklist_w1497265452.m3u8"
            },
            {
                "name": "Cần Thơ 3 HD - Báo và PTTH Thành Phố Cần Thơ",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/CanTho3.png",
                "group": "Địa phương",
                "url": "https://live.canthotv.vn/cs3/tv/chunklist_w1003748170.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "STV HD - Báo và PTTH Sơn La",
                "logo": "https://media.sonlatv.vn/upload/files/image/Back-TH-1.jpg",
                "group": "Địa phương",
                "url": "https://cdn.sonlatv.vn/live/28595222e707a364251b8724717894baa46/chunklist.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "PTV HD - Báo và PTTH Phú Thọ",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/05/16/02/168417957456/7016ca1be5fa_640_360.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=phu-tho",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNNRTV1 - Báo và PTTH Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNNRTV1HD.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=53",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNNRTV2 - Báo và PTTH Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNNRTV2.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=255",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNNRTV3 - Báo và PTTH Đồng Nai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNNRTV3.png",
                "group": "Địa phương",
                "url": "https://tv.vietanhtv.top/vieon/vieon.php?id=dong-nai-3",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "H1 - Báo và PTTH Hà Nội",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/H1.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/fnxhd2/hanoitv1_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "H2 - Báo và PTTH Hà Nội",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/H2.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/fnxhd1/hntv2_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "TTV HD - Báo và PTTH Thanh Hóa",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600821878406/58ff77e57117_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=89",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "QTV1 HD - Báo và PTTH Thành Phố Quảng Ninh",
                "logo": "https://media.baoquangninh.vn/upload/files/logo/QTV1.jpg",
                "group": "Địa phương",
                "url": "https://live.baoquangninh.vn/qtvlive/tv1live.m3u8"
            },
            {
                "name": "QTV3 HD - Báo và PTTH Thành Phố Quảng Ninh",
                "logo": "https://i.ytimg.com/vi/cTNt-U1akXw/hq720.jpg",
                "group": "Địa phương",
                "url": "https://live.baoquangninh.vn/qtvlive/tv3live.m3u8"
            },
            {
                "name": "THVL1 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL1.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/live/media/vinhlong1/live247-hls-avc/vinhlong1-avc1_3800000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THVL2 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL2.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/live/media/vinhlong2/live247-hls-avc/vinhlong2-avc1_3800000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THVL3 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL3.webp",
                "group": "Địa phương",
                "url": "https://vips-livecdn.fptplay.net/live/media/vinhlong3/live247-hls-avc/vinhlong3-avc1_5600000=10000-mp4a_131600=20000.m3u8"
            },
            {
                "name": "THVL4 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL4.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/vinhlong4-hd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
                }
            },
            {
                "name": "THVL5 - Báo và PTTH Vĩnh Long",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/THVL5.webp",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/vinhlong5hd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "ATV2 | Báo và PTTH An Giang",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ATV2.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/angiang02hd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "NBTV - Báo và PTTH Ninh Bình",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/10/07/16/1728293640310/9aea44bf0f8d_640_360.png",
                "group": "Địa phương",
                "url": "https://live.mediatech.vn/live/28597f8fd7ea5064d0f84ab00b3699dfd86/chunklist.m3u8"
            },
            {
                "name": "NTV - Báo và PTTH Nghệ An",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600821989411/75bfb004e210_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=74",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CTV HD - Báo và PTTH Cà Mau",
                "logo": "https://i.ytimg.com/vi/ESIlLqXKqyM/maxresdefault.jpg",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/camauhd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "GTV - Báo và PTTH Gia Lai",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/GTVGIALAI.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=gia-lai",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "KTV HD - Báo và PTTH Khánh Hòa",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/KTV_KhanhHoa.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=khanh-hoa",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Huế TV - Báo và PTTH Huế",
                "logo": "https://i.imgur.com/q5MBibm.png",
                "group": "Địa phương",
                "url": "https://live.huetv.com.vn/TRT-Online/chunklist.m3u8"
            },
            {
                "name": "Tây Ninh TV - Báo và PTTH Tây Ninh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/TayNinhTV.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=72",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "THĐT1 HD - Báo và PTTH Đồng Tháp",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/10/07/16/1728292788373/2f4bec83df66_640_360.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/dongthap01_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "THĐT2 - Báo và PTTH Đồng Tháp",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_mien-tay-thdt2_165666993738.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzhd2/mientaythdt02_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "LTV2 HD - Báo và PTTH Lâm Đồng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/LTV2.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=45",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNRT1 - Báo và PTTH Đà Nẵng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/ĐNRT1.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=49",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐNRT2 - Báo và PTTH Đà Nẵng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/DNRT2_logo.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=80",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ATV1 - Báo và PTTH An Giang",
                "logo": "https://angiangtv.vn/wp-content/uploads/2025/06/H4.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=66",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ATV3 - Báo và PTTH An Giang",
                "logo": "https://angiangtv.vn/wp-content/uploads/2025/06/H5.png",
                "group": "Địa phương",
                "url": "https://live.fptplay53.net/epzsd1/angiang03_hls.smil/chunklist_b2500000.m3u8"
            },
            {
                "name": "LSTV HD - Báo và PTTH Lạng Sơn",
                "logo": "https://langsontv.vn/templates/frontend/lstv/Assets/img/video_bg.png",
                "group": "Địa phương",
                "url": "https://stream.langsontv.vn/live/285c78da0c246524c90917842f8de03bd21/chunklist.m3u8"
            },
            {
                "name": "QTTV - Báo và PTTH Quảng Trị",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/QTTV.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=83",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BHTTV - Báo và PTTH Hà Tĩnh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/BHTTV.webp",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=58",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BTV - Báo và PTTH Bắc Ninh",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/BTVBACNINH.jpg",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=bac-ninh",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CRTV HD - Báo Cao Bằng",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/10/07/16/1728292499129/aeb3499f5824_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=48",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HYTV HD - Báo và PTTH Hưng Yên",
                "logo": "https://hungyentv.vn/templates/frontend/hytv/Assets/img/truyenhinh.jpg",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=hung-yen",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "LTV - Báo Lai Châu",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_lai-chau_165649245279.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=68",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "KTV1 HD - Báo và PTTH Khánh Hòa",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/KTV1_KhanhHoa.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=khanh-hoa-1",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "QNgTV1 - Báo và PTTH Quảng Ngãi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/QNgTV1_QuangNgai.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=81",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "QNgTV2 - Báo và PTTH Quảng Ngãi",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/QNgTV2_QuangNgai.png",
                "group": "Địa phương",
                "url": "https://tv.vietanhtv.top/vieon/vieon.php?id=kon-tum-1",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TTV HD - Báo và PTTH Tuyên Quang",
                "logo": "https://img-zlr1.tv360.vn/image1/2023/05/10/03/1683663305895/0f3f1e5bd284_640_360.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=tuyen-quang",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "TN - Báo và PTTH Thái Nguyên",
                "logo": "https://img-zlr1.tv360.vn/image1/2025/07/01/07/1751329966912/3ddadef93c24_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=88",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ĐTV HD - Báo Điện Biên Phủ",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823593760/3a9a9e608e8d_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=52",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "THLC HD - Báo và PTTH Lào Cai",
                "logo": "https://lichphatsongtivi.com/storage/images/thumbnails/lich-phat-song-thlc.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=71",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "LTV1 HD - Báo và PTTH Lâm Đồng",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/vuminhthanh12/refs/heads/main/LTV1.jpg",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=69",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "HiTV",
                "logo": "https://img-zlr1.tv360.vn/image1/2020_09_23/1600823412691/61627b84a612_640_360.png",
                "group": "Địa phương",
                "url": "https://vmttv.dpdns.org/tv360/?id=hitv",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "YouTV",
                "logo": "https://img-ali1.tv360.vn/image1/2020_09_23/1600823396313/7b474bf7bbce_640_360.png",
                "group": "Địa phương",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=31",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            }
        ],
        "Quốc Tế": [
            {
                "name": "HBO",
                "logo": "https://i.pinimg.com/originals/8b/02/00/8b020050690f955ccb306cdf51324aea.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/hbo.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Asian Food Network",
                "logo": "https://i.vimeocdn.com/video/852785228-36403e3d29153c02a4acfcf0ca4182b0be0bef3e5b43355eafc33614ee972a9b-d?f=webp",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/afchd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "Cinemax HD",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/cinemax.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/max.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cinema World",
                "logo": "https://www.voilah.sg/wp-content/uploads/2020/04/cinema-world-2.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/cinemaworld.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cartoonito",
                "logo": "https://1000logos.net/wp-content/uploads/2023/10/Cartoonito-Logo.jpg",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/boomerang.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Cartoon Network HD",
                "logo": "https://freight.cargo.site/w/1200/i/3cf72163d993c4d87263e6d4990ec4ccdd1e14b09ce89e6e35dee1de83ef4985/CN.jpg",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/cn.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BabyTV",
                "logo": "https://www.babytv.com/app/uploads/2019/12/LogoBabyTV-2019.png",
                "group": "Quốc Tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=960054&extension=ts&play_token=qpvBSWKfyz"
            },
            {
                "name": "Dreamworks",
                "logo": "https://s7266.cdn.mytvnet.vn/vimages/de/eb/ba/a7/7e/ee/deba7-pdreamworkshd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/dreamwork.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC Earth",
                "logo": "https://i.ytimg.com/vi/0jFG4yuzMRo/maxresdefault.jpg",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/bbcearth.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC Lifestyle",
                "logo": "https://images.now-tv.com/shares/channelPreview/img/en_hk/color/ch502_425_305",
                "group": "Quốc Tế",
                "url": "https://s7770.cdn.mytvnet.vn/pkg20/live_dzones/bbclifestyle.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC Cbeebies",
                "logo": "https://s72140.cdn.mytvnet.vn/vimages/7d/d5/58/8c/ce/ea/7d58c-pcbeebieshd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/cbb.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "BBC World News",
                "logo": "https://i.ytimg.com/vi/jL2fsQB9J-g/maxresdefault.jpg",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/bbcworldnews.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Arirang",
                "logo": "https://i.ytimg.com/vi/ZqVyukYe4YM/hq720.jpg",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd1/airanghd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "Bloomberg",
                "logo": "https://i.imgur.com/rxFZgIK.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/bloomberg.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CNBC",
                "logo": "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/30b1d744249569.56076e09dd31e.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd1/cnbchd_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "CNN",
                "logo": "https://deadline.com/wp-content/uploads/2020/09/CNN-Logo.jpg",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/cnn.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CNA",
                "logo": "https://onecms-res.cloudinary.com/image/upload/v1673978069/mediacorp/corporate/inline-images/CNA__370x180.jpg",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=112",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "CGTN",
                "logo": "https://i.ytimg.com/vi/twB_6GV5AM8/hq720.jpg",
                "group": "Quốc Tế",
                "url": "https://english-livebkali.cgtn.com/live/encgtn_0.m3u8"
            },
            {
                "name": "CGTN Documentary",
                "logo": "https://i.ytimg.com/vi/QbB9p0LDAyE/maxresdefault.jpg",
                "group": "Quốc Tế",
                "url": "https://english-livebkali.cgtn.com/live/doccgtn_0.m3u8"
            },
            {
                "name": "TV5Monde",
                "logo": "https://information.tv5monde.com/sites/tv5-info/files/styles/entete/public/2023-11/tv5monde_logo.jpg",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9852",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "DW",
                "logo": "https://i.ytimg.com/vi/puzK9XqJ6-Y/hq720.jpg",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=109",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Da Vinci HD",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_da-vinci-learning_165655659384.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/davincihd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "France 24",
                "logo": "https://m.media-amazon.com/images/I/81oryzEMf-L.png",
                "group": "Quốc Tế",
                "url": "https://live.france24.com/hls/live/2037218/F24_EN_HI_HLS/master_5000.m3u8"
            },
            {
                "name": "KBS World",
                "logo": "https://img.hplus.com.vn/728x409/banner/2018/06/05/654179-KBS.png",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=213",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "NHK World",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/nhkworld.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/nhkworld_vhls.smil/chunklist_b5000000.m3u8"
            },
            {
                "name": "Al Jazeera English",
                "logo": "https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Aljazeera_eng.svg/1280px-Aljazeera_eng.svg.png",
                "group": "Quốc Tế",
                "url": "https://live-hls-web-aje-gcp.thehlive.com/AJE/01.m3u8"
            },
            {
                "name": "TRT World",
                "logo": "https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/425e1955860511.59ae62ac642ba.png",
                "group": "Quốc Tế",
                "url": "https://tv-trtworld.medya.trt.com.tr/master_1080.m3u8"
            },
            {
                "name": "Animal Planet",
                "logo": "https://vnepg.site/logos/143.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/ap.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Discovery",
                "logo": "https://s72140.cdn.mytvnet.vn/vimages/c7/7f/fc/c6/69/9b/c7fc6-pdiscoveryhd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s7770.cdn.mytvnet.vn/pkg20/live_dzones/dsc.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Discovery Asia",
                "logo": "https://astromedia.com.my/wp-content/uploads/2024/01/Discovery-Asia.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/dscasia.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "AXN HD",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/axn.png",
                "group": "Quốc Tế",
                "url": "https://s7771.cdn.mytvnet.vn/pkg20/live_dzones/axn.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Outdoor Channel",
                "logo": "https://images.fptplay53.net/media/channels/icon_channel_outdoor-channel_165649323545.png",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/epzhd2/outdoorfhd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "History HD",
                "logo": "https://img-zlr1.tv360.vn/image1/2024/06/03/22/1717427367441/869de47c9504_640_360.png",
                "group": "Quốc Tế",
                "url": "https://freem3u.xyz/api/live/play.m3u8?vid=9856",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "DMAX",
                "logo": "https://i.imgur.com/vHmt91V.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/dmax.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "ABC Australia",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/abcaustralia.png",
                "group": "Quốc Tế",
                "url": "https://s935.cdn.mytvnet.vn/pkg20/live_dzones/aplus.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Fashion TV",
                "logo": "https://m.media-amazon.com/images/I/91B05VQC2kL.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/ftv.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "KIX HD",
                "logo": "https://static.wikia.nocookie.net/logos/images/2/26/KIX.png/revision/latest/scale-to-width-down/1200?cb=20211017094335&path-prefix=vi",
                "group": "Quốc Tế",
                "url": "https://live.fptplay53.net/fnxhd2/kixhd_vhls.smil/chunklist_b5000000.m3u8",
                "headers": {
                    "User-Agent": "VThanhTivi"
                }
            },
            {
                "name": "TLC",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/7/74/TLC_Logo.svg/1280px-TLC_Logo.svg.png",
                "group": "Quốc Tế",
                "url": "https://s129135.cdn.mytvnet.vn/pkg20/live_dzones/tlc.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Warner TV",
                "logo": "https://s7774.cdn.mytvnet.vn/vimages/6b/ba/a3/36/60/0a/6ba36-pwarnerhd-channel-unkn.png",
                "group": "Quốc Tế",
                "url": "https://s2129134.cdn.mytvnet.vn/pkg20/live_dzones/wtv.smil/manifest.mpd",
                "headers": {
                    "User-Agent": "Dalvik/2.1.0"
                }
            },
            {
                "name": "Filmbox",
                "logo": "https://play-lh.googleusercontent.com/4IkIBkIFApQMYml2sW7XAV21mye06E_X5HssA-WsCRYBHIxWP5BQFzq79t0P5T8MrVs",
                "group": "Quốc Tế",
                "url": "http://line.watchtivo-8k.com:80/play/live.php?mac=00:1A:79:3F:0C:96&stream=1084668&extension=ts&play_token=onuPSPIV6o"
            },
            {
                "name": "HGTV",
                "logo": "https://raw.githubusercontent.com/vuminhthanh12/Logo/refs/heads/main/hgtv.png",
                "group": "Quốc Tế",
                "url": "https://liveh34.vtvprime.vn/hls/HGTV/03.m3u8"
            }
        ],
        "🇰🇷| Hàn Quốc": [
            {
                "name": "CJB SBS",
                "logo": "https://static.wikia.nocookie.net/logos/images/3/3f/CJB.jpg/revision/latest?cb=20200224093248&path-prefix=ko",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://1.222.207.80:1935/live/cjbtv/playlist.m3u8"
            },
            {
                "name": "JTV SBS",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Jtv_logo.svg/250px-Jtv_logo.svg.png?_=20220328012951",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://61.85.197.53:1935/jtv_live/myStream/chunklist_w1542137203.m3u8"
            },
            {
                "name": "G1 SBS",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/G1_broadcasting_logo.svg/250px-G1_broadcasting_logo.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://61.82.49.4:1935/live/_definst_/tv.stream/playlist.m3u8"
            },
            {
                "name": "MBC",
                "logo": "https://img.imbc.com/commons/2018/image/comm2018noti/meta_mbc.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ns1.tjmbc.co.kr/live/myStream.sdp/chunklist_w1392208922.m3u8"
            },
            {
                "name": "MBC Chuncheon",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/5/55/%EC%B6%98%EC%B2%9C_MBC.svg/3840px-%EC%B6%98%EC%B2%9C_MBC.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://stream.chmbc.co.kr/TV/myStream/playlist.m3u8"
            },
            {
                "name": "MBC Chungbuk",
                "logo": "https://i.namu.wiki/i/_ok2k1eWuOVMUOzJvkKfMho8XkxLgcH5iEsIGNhQzDp4aRF14b5Xmix5m89ilmJuHqOg-aMghY-3f6xLgX53_mZGuqrhJ36wlohgy64HTGlhuK8Xeg7eybN6MtuGWP62k4aN6EeDPPNT0_VL4T-GpQ.webp",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://211.33.246.4:32954/cj_live/myStream.sdp/playlist.m3u8"
            },
            {
                "name": "MBC Daegu",
                "logo": "https://imgs.jobkorea.co.kr/img1/_whitebg/200X80/Co_Logo/Logo/2018/8/3/2r1wp00cPs_aWuzporsudz4s2os0ipMuSr_mvdfgo2ps.jpg?v=202607081751&hash=r&serviceCode=CL",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://5ee1ec6f32118.streamlock.net/live/livetv/playlist.m3u8"
            },
            {
                "name": "MBC Jeju",
                "logo": "https://jejumbc.com/main/images/news/jj1.jpg",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://wowza.jejumbc.com/live/tv_jejumbc/playlist.m3u8"
            },
            {
                "name": "MBC Mokpo",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Munhwa_Broadcasting_Corporation.svg/960px-Munhwa_Broadcasting_Corporation.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://vod.mpmbc.co.kr:1935/live/encoder-tv/playlist.m3u8"
            },
            {
                "name": "MBC Yeosu",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/b/b8/MBC_logo.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://5c3639aa99149.streamlock.net/live_TV/tv/playlist.m3u8"
            },
            {
                "name": "EBS1",
                "logo": "https://logowik.com/content/uploads/images/ebs1-20181732222724.logowik.com.webp",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/ebs1familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS2",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/EBS_2TV_Logo.svg/960px-EBS_2TV_Logo.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/ebs2familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS E",
                "logo": "https://cdn.aptoide.com/imgs/6/7/e/67edd0054bd79fb633b11710eeeba298_fgraphic.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/plus3familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS Kids",
                "logo": "https://i.ytimg.com/vi/pra1kNRrxgc/hq720.jpg",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/ebsufamilypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS+1",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/7/70/Channels_IPTV_01.png/revision/latest?cb=20180627174859",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/plus1familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "EBS+2",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/5/5c/Channels_IPTV_02.png/revision/latest?cb=20180627175021",
                "group": "🇰🇷| Hàn Quốc",
                "url": "https://ebsonair.ebs.co.kr/plus2familypc/familypc1m/playlist.m3u8"
            },
            {
                "name": "TV Chosun",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/1/1e/TV_Chosun_Logo_%28English%29.svg/1280px-TV_Chosun_Logo_%28English%29.svg.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://onair.cdn.tvchosun.com/origin1/_definst_/tvchosun_s1/playlist.m3u8",
                "headers": {
                    "Referer": "http://broadcast.tvchosun.com/onair/on.cstv"
                }
            },
            {
                "name": "TV Chosun 2",
                "logo": "https://www.bntnews.co.kr/data/bnt/image/201811/ab30063c0cd3b45d2fec9cd829c428e5.jpg",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://onair.cdn.tvchosun.com/origin1/_definst_/tvchosun_s1/playlist.m3u8",
                "headers": {
                    "Referer": "http://broadcast.tvchosun.com/onair/on.cstv"
                }
            },
            {
                "name": "TVN",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/8/83/TVN_Logo.png",
                "group": "🇰🇷| Hàn Quốc",
                "url": "http://onair2.cdn.tvchosun.com/origin2/_definst_/tvchosun_s3/playlist.m3u8",
                "headers": {
                    "Referer": "http://broadcast.tvchosun.com/onair/on2.cstv"
                }
            }
        ],
        "🇨🇳| Trung Quốc": [
            {
                "name": "CCTV1",
                "logo": "https://images.now-tv.com/shares/channelPreview/img/en_hk/color/ch541_425_305",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv1hd.m3u8"
            },
            {
                "name": "CCTV2",
                "logo": "https://upload.wikimedia.org/wikipedia/he/2/2f/1920px-CCTV-2_Logo.svg.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv2hd.m3u8"
            },
            {
                "name": "CCTV3",
                "logo": "https://static.wikia.nocookie.net/logos/images/f/f2/CCTV3.png/revision/latest/scale-to-width-down/680?cb=20230514030148&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv3hd.m3u8"
            },
            {
                "name": "CCTV4",
                "logo": "https://static.wikia.nocookie.net/logos/images/d/da/CCTV4.png/revision/latest?cb=20230520135601&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv4hd.m3u8"
            },
            {
                "name": "CCTV5",
                "logo": "https://static.wikia.nocookie.net/logos/images/8/86/CCTV5.png/revision/latest/scale-to-width-down/1280?cb=20250201092935&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "https://cdn.qd.je/163189/cctv5"
            },
            {
                "name": "CCTV5+",
                "logo": "https://static.wikia.nocookie.net/logos/images/6/62/CCTV5%2B_logo.png/revision/latest?cb=20220226104639&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "https://cdn.qd.je/163189/cctv5p"
            },
            {
                "name": "CCTV6",
                "logo": "https://static.wikia.nocookie.net/logos/images/d/d9/CCTV6.png/revision/latest?cb=20230816063202&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv6hd.m3u8"
            },
            {
                "name": "CCTV7",
                "logo": "https://static.wikia.nocookie.net/logos/images/a/a6/CCTV7_tr%C6%B0%E1%BB%9Bc_2019.png/revision/latest/scale-to-width-down/1547?cb=20230104111736&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv7hd.m3u8"
            },
            {
                "name": "CCTV8",
                "logo": "https://www.tvchinese.net/uploads/tv/cctv8.jpg",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv8hd.m3u8"
            },
            {
                "name": "CCTV9",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/b/ba/CCTV-9.png/revision/latest?cb=20220111064222",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv9hd.m3u8"
            },
            {
                "name": "CCTV10",
                "logo": "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSmUMEKDTwahilfUCb6CEmVmyRG5vjn-1QAUQ&usqp=CAU",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv10hd.m3u8"
            },
            {
                "name": "h_550/cctv11_logo_by_amazingtoludada3000_dew5uz3-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTUwIiwicGF0aCI6IlwvZlwvZWNkNTEyNjMtYmIwZi00NDY1LWFmODYtZjdlZDI1ZTU4ZTcwXC9kZXc1dXozLTBkM2YzY2FhLTdhYzItNGM5ZC1hYWY1LThhYTZhYmMzM2Y0Yi5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.8ug6Sn5aUfjIJREthEuWeK0cIMretxYjCpnyiH0U2BM\", CCTV11",
                "logo": "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/ecd51263-bb0f-4465-af86-f7ed25e58e70/dew5uz3-0d3f3caa-7ac2-4c9d-aaf5-8aa6abc33f4b.png/v1/fill/w_1280,h_550/cctv11_logo_by_amazingtoludada3000_dew5uz3-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9NTUwIiwicGF0aCI6IlwvZlwvZWNkNTEyNjMtYmIwZi00NDY1LWFmODYtZjdlZDI1ZTU4ZTcwXC9kZXc1dXozLTBkM2YzY2FhLTdhYzItNGM5ZC1hYWY1LThhYTZhYmMzM2Y0Yi5wbmciLCJ3aWR0aCI6Ijw9MTI4MCJ9XV0sImF1ZCI6WyJ1cm46c2VydmljZTppbWFnZS5vcGVyYXRpb25zIl19.8ug6Sn5aUfjIJREthEuWeK0cIMretxYjCpnyiH0U2BM",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv11hd.m3u8"
            },
            {
                "name": "CCTV12",
                "logo": "https://static.wikia.nocookie.net/logos/images/7/7b/CCTV12.png/revision/latest/scale-to-width-down/1131?cb=20230513114830&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv12hd.m3u8"
            },
            {
                "name": "CCTV13",
                "logo": "https://static.wikia.nocookie.net/logos/images/e/e4/CCTV13.png/revision/latest/scale-to-width-down/1131?cb=20230513114844&path-prefix=vi",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv13hd.m3u8"
            },
            {
                "name": "CCTV14",
                "logo": "https://static.wikia.nocookie.net/happy-heroes/images/c/c8/CCTV-14_Logo.png/revision/latest?cb=20201002050804",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv14hd.m3u8"
            },
            {
                "name": "CCTV15",
                "logo": "https://i.imgur.com/MXep2Zc.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv15hd.m3u8"
            },
            {
                "name": "CCTV16",
                "logo": "https://static.wikia.nocookie.net/logopedia/images/3/39/CCTV-16.png/revision/latest?cb=20211107032828",
                "group": "🇨🇳| Trung Quốc",
                "url": "https://cdn.qd.je/163189/cctv16"
            },
            {
                "name": "CCTV17",
                "logo": "https://i.imgur.com/omJsYRq.png",
                "group": "🇨🇳| Trung Quốc",
                "url": "http://74.91.26.218:82/live/cctv17hd.m3u8"
            }
        ],
        "🇹🇭| Thái Lan": [
            {
                "name": "PPTV36",
                "logo": "https://image.makewebcdn.com/makeweb/m_1920x0/fwsVrxqVa/3PPTV36/PPTV_By_HSTN.jpg",
                "group": "🇹🇭| Thái Lan",
                "url": "http://3bb.engatetv.com:25461/hstn/line/21"
            },
            {
                "name": "MONOMAX SPORT",
                "logo": "https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/MONOMAX_Sports_2026.svg/500px-MONOMAX_Sports_2026.svg.png",
                "group": "🇹🇭| Thái Lan",
                "url": "http://3bb.engatetv.com:25461/hstn/line/14"
            },
            {
                "name": "Thairath TV 32",
                "logo": "https://www.thairath.co.th/assets/tv/img/share_tv.jpg",
                "group": "🇹🇭| Thái Lan",
                "url": "http://3bb.engatetv.com:25461/hstn/line/17"
            }
        ]
    }
};
