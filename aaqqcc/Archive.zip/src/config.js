let BASE_URL = 'https://aaqqcc.com';
let BASE_URL1 = 'https://www.aaqqcc.com';
try {
    if (CONFIG_URL) {
        BASE_URL = CONFIG_URL;
        BASE_URL1 = CONFIG_URL;
    }
} catch (error) {
}